# Discord-Ddos-Bot-
Source bot ddos

Bot chạy bằng ngôn ngữ Python + Javascript  

![Alt text](https://scontent.fhph1-1.fna.fbcdn.net/v/t1.15752-9/312832518_427326822936268_2896170771227308432_n.png?_nc_cat=100&ccb=1-7&_nc_sid=ae9488&_nc_ohc=eoIjQHSsZtUAX-Pa31e&_nc_ht=scontent.fhph1-1.fna&oh=03_AdSZHrxwvQyrwRlg_vcqPTFkcf2R9Xy3YsfuR__ej2C7IQ&oe=63971258 "Optional title")
![Alt text](https://scontent.fhph1-1.fna.fbcdn.net/v/t1.15752-9/310634619_943090673331990_8619500911717070380_n.png?_nc_cat=100&ccb=1-7&_nc_sid=ae9488&_nc_ohc=RwDbHC2QVHEAX9WqOd4&_nc_ht=scontent.fhph1-1.fna&oh=03_AdT63rgV9rxtVqUYO6ef6chRGiZfpxVcvQaAFPzNzJZmag&oe=63971301 "Optional title")

Hỏi về pass sao? Vì tui hơi tồi và bot cũng free nên vượt link để lấy pass :)))) Link : http://traffic1s.com/passkataddos

Cách setup:
+ chạy file setup.py ( nếu vẫn thiếu thư viện thì pip install thêm )
+ tải nodejs 
+ acp intents ở https://discord.com/developers/applications/
+ thay token và user ID 
+ chạy file bot.py

Ghi ra đây cũng chả hiểu đâu nên xem vd
Link vd hd : https://www.youtube.com/watch?v=pCOoW8FnMWU
